<?php
/**
 * WTE Template component builder.
 */
